(() => {
  const $ = (s, root=document) => root.querySelector(s);
  const $$ = (s, root=document) => [...root.querySelectorAll(s)];
  const STORE = 'parvaz-daily-v1';
  const sections = {
    daily:{title:'روزانه و حال من',en:'MY DAILY DIARY',subtitle:'برای حال امروزت، اتفاق‌ها و کارهای کوچکت جا باز کن.',fields:[['title','عنوان کار یا اتفاق','text'],['date','تاریخ','date'],['mood','حال امروز','select',['خیلی خوب ✨','خوب 🌷','معمولی ☁️','خسته 🌙','دلگیر 🌧️']],['note','خاطره یا توضیحات','textarea']],kind:'daily'},
    study:{title:'اتاق مطالعه',en:"THE SCHOLAR'S STUDY",subtitle:'درس‌ها، برنامه مطالعه و نکته‌هایی که نمی‌خوای فراموش کنی.',fields:[['title','عنوان درس یا نکته','text'],['date','تاریخ','date'],['category','نوع','select',['برنامه مطالعه','نکته مهم','یادداشت','کار درسی']],['note','توضیحات / نکات','textarea']],kind:'study'},
    plants:{title:'باغچه‌ی من',en:'BOTANICA',subtitle:'هر برگ با کمی توجه، داستان تازه‌ای شروع می‌کند.',fields:[['title','نام گل یا گیاه','text'],['date','تاریخ آبیاری بعدی','date'],['category','مراقبت','select',['آبیاری','کوددهی','تعویض گلدان','بررسی سلامت']],['note','یادداشت مراقبت','textarea']],kind:'plants'},
    reading:{title:'کتابخانه جادویی',en:'A FANTASY LIBRARY',subtitle:'ردّ کتاب‌هایی که خواندی و احساس‌هایی که در تو جا گذاشتند.',fields:[['title','نام کتاب یا رمان','text'],['date','تاریخ','date'],['category','وضعیت کتاب','select',['در حال خواندن','خوانده‌شده','برای خواندن']],['note','نقد، امتیاز یا یادداشت','textarea']],kind:'reading'},
    wellness:{title:'تغذیه و ورزش',en:'SOFT LIVING',subtitle:'مراقبت از خودت قرار نیست سخت یا بی‌نقص باشد.',fields:[['title','وعده غذایی یا فعالیت','text'],['date','تاریخ','date'],['category','نوع ثبت','select',['صبحانه','ناهار','شام','میان‌وعده','ورزش','حال خوب']],['note','توضیحات (اختیاری)','textarea']],kind:'wellness'},
    money:{title:'دفتر هزینه‌ها',en:'LITTLE TREASURES',subtitle:'با آگاهی از خرج‌های کوچک، تصویر روشن‌تری از پولت داشته باش.',fields:[['title','عنوان هزینه','text'],['amount','مبلغ (تومان)','number'],['date','تاریخ','date'],['note','توضیحات (اختیاری)','textarea']],kind:'money'}
  };
  let db = {}; try { db = JSON.parse(localStorage.getItem(STORE) || '{}'); } catch { db = {}; }
  Object.keys(sections).forEach(k => { if (!Array.isArray(db[k])) db[k] = []; });
  let active = null;
  const today = new Date();
  const localDate = `${today.getFullYear()}-${String(today.getMonth()+1).padStart(2,'0')}-${String(today.getDate()).padStart(2,'0')}`;
  const faDate = new Intl.DateTimeFormat('fa-IR',{weekday:'long',day:'numeric',month:'long'}).format(today);
  $('#todayDate').textContent = `${faDate}  ·  امروز را برای خودت زندگی کن`;
  const faNum = n => Number(n||0).toLocaleString('fa-IR');
  const escapeHTML = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const save = () => { localStorage.setItem(STORE, JSON.stringify(db)); updateProgress(); };
  function updateProgress(){ const items=db.daily; const done=items.filter(x=>x.done).length; $('#progressText').textContent=`${faNum(done)} کار از ${faNum(items.length)} کار انجام شده`; }
  function fieldHTML(f){const [key,label,type,opts]=f; if(type==='textarea')return `<textarea name="${key}" placeholder="${label}"></textarea>`;if(type==='select')return `<select name="${key}" aria-label="${label}">${opts.map(o=>`<option>${escapeHTML(o)}</option>`).join('')}</select>`;return `<input name="${key}" type="${type}" placeholder="${label}" aria-label="${label}" ${key==='title'?'required':''} ${key==='date'?`value="${localDate}"`:''} ${key==='amount'?'min="0" step="any"':''}>`;}
  function openSection(key){active=key;const s=sections[key];$('#sectionPanel').classList.remove('hidden');$('#panelEyebrow').textContent=s.en;$('#panelTitle').textContent=s.title;$('#panelSubtitle').textContent=s.subtitle;renderPanel();$('#sectionPanel').scrollIntoView({behavior:'smooth',block:'start'});}
  function renderPanel(){const s=sections[active];const money=active==='money';const total=money?db.money.reduce((sum,x)=>sum+Number(x.amount||0),0):0;
    let html=money?`<div class="sum-box">جمع هزینه‌های ثبت‌شده<strong>${faNum(total)} تومان</strong></div>`:'';
    html+=`<form class="entry-form" id="entryForm">${s.fields.map(f=>`<label class="${f[2]==='textarea'?'full':''}">${fieldHTML(f)}</label>`).join('')}<button class="full" type="submit">＋ ثبت در دفتر من</button></form><div class="entry-list" id="entryList"></div>`;
    $('#panelContent').innerHTML=html;
    $('#entryForm').addEventListener('submit',e=>{e.preventDefault();const fd=new FormData(e.currentTarget);const item={id:Date.now().toString(36)+Math.random().toString(36).slice(2,6)};s.fields.forEach(f=>item[f[0]]=String(fd.get(f[0])||'').trim());if(!item.title){const titleField=$('[name="title"]',e.currentTarget);if(titleField){titleField.focus();return;}}if(money&&(!item.amount||Number(item.amount)<0)){alert('لطفاً مبلغ معتبر وارد کن.');return;}if(money)item.amount=Number(item.amount);if(!item.date&&s.fields.some(f=>f[0]==='date'))item.date=localDate;item.done=false;db[active].unshift(item);save();renderPanel();});
    renderEntries();
  }
  function renderEntries(){const list=$('#entryList');if(!db[active].length){list.innerHTML='<div class="empty-state">هنوز چیزی اینجا ننوشتی؛ اولین یادداشتت رو ثبت کن ✨</div>';return;}
    list.innerHTML=db[active].map(item=>{const isTask=active==='daily';const titleClass=item.done?'done-title':'';const details=[item.category,item.mood,item.amount!==undefined&&item.amount!==''?`${faNum(item.amount)} تومان`:null].filter(Boolean).join(' · ');return `<article class="entry-item">${isTask?`<input type="checkbox" aria-label="انجام شد" data-done="${item.id}" ${item.done?'checked':''}>`:''}<div class="entry-body"><strong class="${titleClass}">${escapeHTML(item.title||'بدون عنوان')}</strong>${item.note?`<p>${escapeHTML(item.note)}</p>`:''}${details?`<div class="entry-meta">${escapeHTML(details)}</div>`:''}${item.date?`<div class="entry-meta">${escapeHTML(item.date)}</div>`:''}</div><button class="delete" data-delete="${item.id}" aria-label="حذف مورد">حذف</button></article>`;}).join('');
    $$('[data-delete]',list).forEach(btn=>btn.addEventListener('click',()=>{db[active]=db[active].filter(x=>x.id!==btn.dataset.delete);save();renderPanel();}));
    $$('[data-done]',list).forEach(ch=>ch.addEventListener('change',()=>{const item=db[active].find(x=>x.id===ch.dataset.done);if(item)item.done=ch.checked;save();renderEntries();}));
  }
  $$('.world-card').forEach(btn=>btn.addEventListener('click',()=>openSection(btn.dataset.section)));
  $('#backButton').addEventListener('click',()=>{$('#sectionPanel').classList.add('hidden');active=null;document.querySelector('.welcome').scrollIntoView({behavior:'smooth',block:'start'});});
  updateProgress();
})();
