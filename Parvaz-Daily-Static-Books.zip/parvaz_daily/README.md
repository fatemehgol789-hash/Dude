# Parvaz Daily ✦

A Persian, RTL, mobile-first personal dashboard with a soft fantasy-library aesthetic.

## Files
- `index.html` — main page and all six sections
- `style.css` — responsive design, pastel cards, floating-books animation
- `script.js` — add and delete entries, daily task checkboxes, expense totals, browser storage
- `assets/floating-books.png` — fantasy book artwork for the hero section

## How to use
1. Keep the `assets` folder beside the three main files.
2. Open `index.html` in a browser. No installation or build step is required.
3. Choose a section on the home page and add your entries. Data is stored in that browser on that device using localStorage.

## Publishing
Upload all files and the `assets` folder to the root of a GitHub repository. For GitHub Pages, choose the `main` branch and `/ (root)` in Settings → Pages. Wait for publishing to finish, then use the provided Pages URL.

Note: GitHub showing “100% HTML” in its Languages bar is only a language estimate, not an error. A local browser preview opened from a `content://` address is not the published GitHub Pages URL.
